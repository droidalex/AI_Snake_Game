import pygame
import random
import sys
import asyncio # 1. Importação necessária

# Configurações permanecem as mesmas
WINDOW_WIDTH = 640
WINDOW_HEIGHT = 480
GRID_SIZE = 20
GRID_WIDTH = WINDOW_WIDTH // GRID_SIZE
GRID_HEIGHT = WINDOW_HEIGHT // GRID_SIZE
FPS = 10

BLACK = (0, 0, 0); WHITE = (255, 255, 255); GREEN = (0, 255, 0)
DARK_GREEN = (0, 128, 0); RED = (255, 0, 0); BLUE = (0, 255, 0)

UP = (0, -1); DOWN = (0, 1); LEFT = (-1, 0); RIGHT = (1, 0)

# ... (As classes Snake e Food permanecem IGUAIS ao seu código original) ...
class Snake:
    def __init__(self): self.reset()
    def reset(self):
        center_x = GRID_WIDTH // 2
        center_y = GRID_HEIGHT // 2
        self.body = [(center_x, center_y), (center_x - 1, center_y), (center_x - 2, center_y)]
        self.direction = RIGHT
        self.grow = False
    def change_direction(self, new_direction):
        if (new_direction[0] * -1, new_direction[1] * -1) != self.direction:
            self.direction = new_direction
    def move(self):
        head_x, head_y = self.body[0]
        new_head = (head_x + self.direction[0], head_y + self.direction[1])
        self.body.insert(0, new_head)
        if not self.grow: self.body.pop()
        else: self.grow = False
    def eat(self): self.grow = True
    def check_collision(self):
        head = self.body[0]
        if (head[0] < 0 or head[0] >= GRID_WIDTH or head[1] < 0 or head[1] >= GRID_HEIGHT): return True
        if head in self.body[1:]: return True
        return False
    def draw(self, surface):
        for i, segment in enumerate(self.body):
            x = segment[0] * GRID_SIZE; y = segment[1] * GRID_SIZE
            rect = pygame.Rect(x, y, GRID_SIZE, GRID_SIZE)
            color = GREEN if i == 0 else DARK_GREEN
            pygame.draw.rect(surface, color, rect)
            pygame.draw.rect(surface, BLACK, rect, 1)

class Food:
    def __init__(self):
        self.position = (0, 0)
        self.spawn()
    def spawn(self, snake_body=None):
        while True:
            x = random.randint(0, GRID_WIDTH - 1)
            y = random.randint(0, GRID_HEIGHT - 1)
            if snake_body is None or (x, y) not in snake_body:
                self.position = (x, y); break
    def draw(self, surface):
        x = self.position[0] * GRID_SIZE; y = self.position[1] * GRID_SIZE
        rect = pygame.Rect(x + 2, y + 2, GRID_SIZE - 4, GRID_SIZE - 4)
        pygame.draw.rect(surface, RED, rect)

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("🐍 Snake Game")
        self.font_large = pygame.font.Font(None, 72)
        self.font_medium = pygame.font.Font(None, 48)
        self.font_small = pygame.font.Font(None, 36)
        self.clock = pygame.time.Clock()
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.high_score = 0
        self.game_over = False

    def draw_background(self):
        self.screen.fill(BLACK)
        for x in range(0, WINDOW_WIDTH, GRID_SIZE):
            pygame.draw.line(self.screen, (30, 30, 30), (x, 0), (x, WINDOW_HEIGHT))
        for y in range(0, WINDOW_HEIGHT, GRID_SIZE):
            pygame.draw.line(self.screen, (30, 30, 30), (0, y), (WINDOW_WIDTH, y))

    def draw_score(self):
        score_text = self.font_small.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_text, (10, 10))

    def draw_game_over(self):
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        overlay.fill(BLACK); overlay.set_alpha(180)
        self.screen.blit(overlay, (0, 0))
        game_over_text = self.font_large.render("GAME OVER", True, RED)
        self.screen.blit(game_over_text, game_over_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 - 60)))
        restart_text = self.font_small.render("Press SPACE to play again", True, GREEN)
        self.screen.blit(restart_text, restart_text.get_rect(center=(WINDOW_WIDTH//2, WINDOW_HEIGHT//2 + 60)))

    def restart_game(self):
        self.snake.reset(); self.food.spawn(); self.score = 0; self.game_over = False

    # 2. A função RUN agora é ASYNC
    async def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if self.game_over:
                        if event.key == pygame.K_SPACE: self.restart_game()
                    else:
                        if event.key in (pygame.K_UP, pygame.K_w): self.snake.change_direction(UP)
                        elif event.key in (pygame.K_DOWN, pygame.K_s): self.snake.change_direction(DOWN)
                        elif event.key in (pygame.K_LEFT, pygame.K_a): self.snake.change_direction(LEFT)
                        elif event.key in (pygame.K_RIGHT, pygame.K_d): self.snake.change_direction(RIGHT)

            if not self.game_over:
                self.snake.move()
                if self.snake.body[0] == self.food.position:
                    self.snake.eat()
                    self.score += 10
                    self.food.spawn(self.snake.body)
                if self.snake.check_collision():
                    self.game_over = True

            self.draw_background()
            self.food.draw(self.screen)
            self.snake.draw(self.screen)
            self.draw_score()
            if self.game_over: self.draw_game_over()
            
            pygame.display.flip()
            
            # 3. A mágica para funcionar na Web
            await asyncio.sleep(0) 
            self.clock.tick(FPS)

# 4. Ponto de entrada ajustado para asyncio
async def main():
	pygame.init()
	game = Game()
	await game.run()

if __name__ == "__main__":
    asyncio.run(main())
